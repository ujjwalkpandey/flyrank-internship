# Ujjwal Pandey — AI Fluency Portfolio

Static portfolio + working browser personal agent.

## Before launch
1. Replace `REPLACE_WITH_YOUR_EMAIL@example.com` in `index.html`.
2. Add your real LinkedIn URL if desired.
3. Add the official FlyRank graduate badge only after FlyRank provides the verification link.
4. Never publish API keys, HF tokens, client identifiers, raw exports, private URLs or queries.

## Deploy
- GitHub Pages: publish `/docs` from `main`.
- Netlify: deploy the `docs` folder.

## Agent
The current agent is deliberately deterministic and browser-only. It answers from `assets/agent.js`; it does not pretend to be a general autonomous LLM. For a real LLM agent, use a server-side API route and keep secrets off the browser.

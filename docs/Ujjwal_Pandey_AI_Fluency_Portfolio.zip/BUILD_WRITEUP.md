# AI Fluency Capstone — Build Write-up

## What I made
A portfolio proving one claim: I can turn messy search data into clear decisions.

## Stack decision
Plain HTML, CSS and JavaScript keep the first release portable, fast and easy to inspect. The personal agent works without exposing an API key.

## Where AI helped
AI helped structure the portfolio, turn real internship work into case-study framing, generate the first implementation and iterate on the interaction. Human ownership stayed with the claims and validation.

## What broke / limitation
AI-generated portfolio copy can become generic. I anchored every case in the real problem, decisions, evidence and limits. The agent is intentionally limited to a controlled public knowledge base.

## Next
Build a server-side retrieval agent with citations, an evaluation set, and analytics on the questions visitors actually ask.

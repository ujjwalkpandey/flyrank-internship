# Build in public

I wanted a portfolio that proved something instead of simply listing skills. I built around my FlyRank search-intelligence work and made the reasoning visible: what decision matters, what the data can support, and where the model should stop.

AI helped with structure, implementation and iteration. It did not get to decide what my evidence meant.

The current personal agent is intentionally small. It answers from a controlled public knowledge base rather than pretending to know everything. That limitation is part of the design: a useful agent should be trustworthy before it is impressive.

The next version will add retrieval, citations and a real evaluation set.

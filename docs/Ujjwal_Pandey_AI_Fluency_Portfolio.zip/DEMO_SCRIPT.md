# Demo script (3–5 minutes)

1. Open the hero and state: “I turn messy search data into clear decisions.”
2. Open the ML case study. Explain the decision, CTR/engagement lane, time-aware setup, leakage checks, baseline/model comparison and ranked recommendations.
3. Open the personal agent. Ask “What did he build for the ML capstone?” and “How does he use AI?”
4. Explain that AI helped with structure, implementation and iteration, while the final claims stayed human-reviewed.
5. End at Contact: “If you have a search, ML or AI-workflow problem worth testing, start a conversation.”
